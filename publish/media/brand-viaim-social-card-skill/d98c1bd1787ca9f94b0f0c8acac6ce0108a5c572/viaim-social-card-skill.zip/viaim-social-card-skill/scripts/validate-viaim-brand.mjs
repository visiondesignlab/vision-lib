import { createHash } from 'node:crypto'
import { existsSync, readFileSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const failures = []

const expected = {
  'signal-fog': '#F2F1F1',
  'blank-state': '#FFFFFF',
  'vision-orange': '#FF3B0F',
  'neutral-ash': '#666666',
  'silent-black': '#000000',
}

function check(condition, message) {
  if (!condition) failures.push(message)
}

const templateNames = ['template-editorial-card.html', 'template-swiss-card.html']
for (const name of templateNames) {
  const path = join(root, 'assets', name)
  check(existsSync(path), `missing ${name}`)
  if (!existsSync(path)) continue
  const source = readFileSync(path, 'utf8')
  check(/<html[^>]+data-theme="viaim"/.test(source), `${name}: default theme is not viaim`)
  check(source.includes('[data-theme="viaim"]'), `${name}: missing viaim theme block`)
  check(source.includes('[data-theme="viaim"] :is([data-accent],[data-theme])'), `${name}: nested theme overrides are not locked to viaim`)
  check(source.includes('VIAIM:BRAND:START'), `${name}: missing brand block marker`)
  check(source.includes('class="brand-logo') || source.includes('.brand-logo'), `${name}: missing logo treatment`)
  for (const [token, value] of Object.entries(expected)) {
    check(source.includes(`--brand-${token}:${value};`), `${name}: missing --brand-${token}:${value}`)
  }
}

const recipePath = join(root, 'references', 'layout-recipes.md')
const recipes = existsSync(recipePath) ? readFileSync(recipePath, 'utf8') : ''
check(!recipes.includes('data-accent='), 'layout recipes still contain legacy accent overrides')

const screenshotPath = join(root, 'references', 'screenshot-treatment.md')
const screenshots = existsSync(screenshotPath) ? readFileSync(screenshotPath, 'utf8') : ''
check(!screenshots.includes('bg-asset-'), 'screenshot treatment still references legacy colored texture assets')
check(!existsSync(join(root, 'assets', 'screenshot-backgrounds')), 'legacy colored screenshot assets are still bundled')

const skillPath = join(root, 'SKILL.md')
const skill = existsSync(skillPath) ? readFileSync(skillPath, 'utf8') : ''
check(Boolean(skill), 'missing SKILL.md')
check(!skill.includes('[TODO'), 'SKILL.md contains TODO scaffold text')
check(skill.includes('data-theme="viaim"'), 'SKILL.md does not require the viaim theme')
for (const value of Object.values(expected)) {
  check(skill.includes(value), `SKILL.md missing brand value ${value}`)
}

const logoPath = join(root, 'assets', 'viaim-logo', 'viaim-logo-master.svg')
check(existsSync(logoPath), 'missing viaim logo master')
if (existsSync(logoPath)) {
  const hash = createHash('sha256').update(readFileSync(logoPath)).digest('hex')
  check(hash === 'b9fd8b1b3c5f70e32fd9c4744dfc9c88d8b93834bc2f353aeb599b68239f6da0', `logo hash mismatch: ${hash}`)
}

if (failures.length) {
  for (const failure of failures) console.error(`FAIL ${failure}`)
  process.exit(1)
}

console.log(`VIAIM_BRAND_OK palette=${Object.keys(expected).length} templates=${templateNames.length} logo=master`)
